﻿using System;
namespace adventureCodeReading
{
    public class Item
    {
        public string Name;
        public string Description;


        public Item(string _name, string _desc)
        {
            Name = _name;
            Description = _desc;
        }
    }
}
